export default interface Usuario {
    email: string
    nome: string
    telefone?: string
}
