import Servico from './Servico'
export type { Servico }
