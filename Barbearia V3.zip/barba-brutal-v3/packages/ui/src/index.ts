import useServicos from "./hooks/useServicos"
import useProfissionais from "./hooks/useProfissionais"

export { useServicos, useProfissionais }