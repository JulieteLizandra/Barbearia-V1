const clientes = [
    {
        id: 1,
        imagemURL: '/clientes/cliente-1.jpg',
        nome: 'Ricardo Soundbar',
        testemunho:
            'Chega falando alto e ocupando espaço com seu tamanho de viking, mas que tem um coração do tamanho de seu topete! Um verdadeiro gigante gente boa, ele sempre diz: "Os caras aqui são brutais no corte e na amizade! Serviço top, recomendo de olhos fechados!"',
    },
    {
        id: 2,
        imagemURL: '/clientes/cliente-2.jpg',
        nome: 'Tiaguinho - "O Atacante"',
        testemunho:
            'Fanático por futebol! Ele sempre chega animado, pronto para bater um papo e discutir o último jogo. Tiaguinho sempre diz: "Cortar cabelo aqui é muito legal, mas eu prefiro fazer gol!"',
    },
    {
        id: 3,
        imagemURL: '/clientes/cliente-3.jpg',
        nome: 'Patrícia',
        testemunho:
            'Nossa cliente com o cabelo mais vermelho do bairro e uma paixão por doramas que não tem fim! Patrícia diz: "Aqui é meu lugar favorito! Saio com o cabelo perfeito e ainda compartilho todos os dramas dos doramas. Serviço top demais!"',
    },
    {
        id: 4,
        imagemURL: '/clientes/cliente-4.jpg',
        nome: 'Sr. Carlos',
        testemunho:
            'Nosso cliente mais velho e cheio de histórias incríveis que nunca se repetem! Ele anima a barbearia com suas aventuras e sabedoria. Sr. Carlos diz: "A Barba Brutal é raiz, me lembra a barbearia que eu ia quando era moleque. Serviço excelente e histórias boas garantidas"',
    },
]

export default clientes
