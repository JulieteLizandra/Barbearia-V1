import clientes from './clientes'
import profissionais from './profissionais'
import servicos from './servicos'

const TEMPO_SLOT = 15
export { TEMPO_SLOT, clientes, profissionais, servicos }
