import Usuario from './Usuario'

export type { Usuario }
