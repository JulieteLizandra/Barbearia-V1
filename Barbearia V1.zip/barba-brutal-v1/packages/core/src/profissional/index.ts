import Profissional from './Profissional'

export type { Profissional }
