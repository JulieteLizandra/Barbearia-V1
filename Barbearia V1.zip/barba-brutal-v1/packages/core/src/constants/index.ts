import clientes from './clientes'
import profissionais from './profissionais'
import servicos from './servicos'

export { clientes, profissionais, servicos }
