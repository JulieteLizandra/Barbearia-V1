import { servicos } from '@barba/core'

export default function useServicos() {
    return {
        servicos,
    }
}
