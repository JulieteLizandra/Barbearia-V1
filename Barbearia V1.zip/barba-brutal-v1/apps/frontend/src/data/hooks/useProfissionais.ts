import { profissionais } from '@barba/core'

export default function useProfissionais() {
    return {
        profissionais,
    }
}
