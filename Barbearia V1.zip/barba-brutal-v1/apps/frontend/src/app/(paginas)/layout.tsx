'use client'
import { ProvedorUsuario } from '@/data/contexts/ContextoUsuario'

export default function Layout({ children }: any) {
    return <ProvedorUsuario>{children}</ProvedorUsuario>
}
